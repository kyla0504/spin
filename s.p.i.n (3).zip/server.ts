import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import twilio from "twilio";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";

dotenv.config();

const JWT_SECRET = process.env.JWT_SECRET || "spin-laundry-secret-key-2024";

// In-memory "Database"
const db = {
  users: [] as any[],
  bookings: [] as any[],
  // Default admin: admin / admin123
  admins: [{ username: "admin", email: "admin@spin.systems", password: "adminPassword123" }] 
};

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Twilio Client (Lazy initialized)
  let twilioClient: any = null;
  function getTwilio() {
    if (!twilioClient) {
      const sid = process.env.TWILIO_ACCOUNT_SID;
      const token = process.env.TWILIO_AUTH_TOKEN;
      if (!sid || !token) {
        console.warn("Twilio credentials missing. SMS notifications will be disabled.");
        return null;
      }
      twilioClient = twilio(sid, token);
    }
    return twilioClient;
  }

  // Auth Middleware
  const authenticate = (req: any, res: any, next: any) => {
    const token = req.headers.authorization?.split(" ")[1];
    if (!token) return res.status(401).json({ error: "Unauthorized" });

    try {
      const decoded = jwt.verify(token, JWT_SECRET);
      req.user = decoded;
      next();
    } catch (err) {
      res.status(401).json({ error: "Invalid token" });
    }
  };

  // API Routes
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // --- Auth Routes ---
  app.post("/api/auth/register", async (req, res) => {
    const { password, name, phone } = req.body;
    if (db.users.find(u => u.phone === phone)) {
      return res.status(400).json({ error: "Phone number already registered" });
    }
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = { id: Date.now().toString(), password: hashedPassword, name, phone };
    db.users.push(user);
    
    const token = jwt.sign({ id: user.id, name: user.name, phone: user.phone }, JWT_SECRET);
    res.json({ token, user: { id: user.id, name: user.name, phone: user.phone } });
  });

  app.post("/api/auth/login", async (req, res) => {
    const { phone, password } = req.body;
    const user = db.users.find(u => u.phone === phone);
    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.status(401).json({ error: "Invalid credentials" });
    }
    const token = jwt.sign({ id: user.id, name: user.name, phone: user.phone }, JWT_SECRET);
    res.json({ token, user: { id: user.id, name: user.name, phone: user.phone } });
  });

  app.post("/api/auth/admin-login", (req, res) => {
    const { username, password } = req.body;
    // Default admin: admin / admin123
    const admin = db.admins.find(a => (a.username === username || a.email === username) && a.password === password);
    if (!admin) return res.status(401).json({ error: "Invalid admin credentials" });
    
    const token = jwt.sign({ username: admin.username, isAdmin: true }, JWT_SECRET);
    res.json({ token, user: { username: admin.username, isAdmin: true } });
  });

  // --- Booking Routes ---
  app.get("/api/bookings", authenticate, (req: any, res) => {
    if (req.user.isAdmin) {
      return res.json(db.bookings);
    }
    const userBookings = db.bookings.filter(b => b.customerId === req.user.id);
    res.json(userBookings);
  });

  app.post("/api/bookings", authenticate, (req: any, res) => {
    const booking = {
      ...req.body,
      id: Date.now().toString(),
      customerId: req.user.id,
      customerName: req.user.name,
      customerPhone: req.user.phone,
      status: "Pending",
      createdAt: new Date().toISOString()
    };
    db.bookings.push(booking);
    res.json(booking);
  });

  app.patch("/api/bookings/:id", authenticate, (req: any, res) => {
    if (!req.user.isAdmin) return res.status(403).json({ error: "Forbidden" });
    const { id } = req.params;
    const index = db.bookings.findIndex(b => b.id === id);
    if (index === -1) return res.status(404).json({ error: "Booking not found" });
    
    db.bookings[index] = { ...db.bookings[index], ...req.body, updatedAt: new Date().toISOString() };
    res.json(db.bookings[index]);
  });

  app.post("/api/notify", async (req, res) => {
    const { phone, message } = req.body;

    if (!phone || !message) {
      return res.status(400).json({ error: "Phone and message are required" });
    }

    const client = getTwilio();
    if (!client) {
      console.log(`[MOCK SMS] To ${phone}: ${message}`);
      return res.json({ success: true, mock: true, message: "SMS sent (mocked)" });
    }

    try {
      await client.messages.create({
        body: message,
        to: phone,
        from: process.env.TWILIO_PHONE_NUMBER,
      });
      res.json({ success: true });
    } catch (error) {
      console.error("Twilio Error:", error);
      res.status(500).json({ error: "Failed to send SMS" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
