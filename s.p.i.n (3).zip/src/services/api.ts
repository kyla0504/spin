const API_URL = "";

const getHeaders = () => {
  const token = localStorage.getItem("token");
  return {
    "Content-Type": "application/json",
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
};

export const api = {
  auth: {
    register: async (data: any) => {
      const res = await fetch(`${API_URL}/api/auth/register`, {
        method: "POST",
        headers: getHeaders(),
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error((await res.json()).error);
      return res.json();
    },
    login: async (data: any) => {
      const res = await fetch(`${API_URL}/api/auth/login`, {
        method: "POST",
        headers: getHeaders(),
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error((await res.json()).error);
      return res.json();
    },
    adminLogin: async (data: any) => {
      const res = await fetch(`${API_URL}/api/auth/admin-login`, {
        method: "POST",
        headers: getHeaders(),
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error((await res.json()).error);
      return res.json();
    },
  },
  bookings: {
    getAll: async () => {
      const res = await fetch(`${API_URL}/api/bookings`, { headers: getHeaders() });
      if (!res.ok) throw new Error((await res.json()).error);
      return res.json();
    },
    create: async (data: any) => {
      const res = await fetch(`${API_URL}/api/bookings`, {
        method: "POST",
        headers: getHeaders(),
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error((await res.json()).error);
      return res.json();
    },
    update: async (id: string, data: any) => {
      const res = await fetch(`${API_URL}/api/bookings/${id}`, {
        method: "PATCH",
        headers: getHeaders(),
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error((await res.json()).error);
      return res.json();
    },
  },
  notify: async (phone: string, message: string) => {
    const res = await fetch(`${API_URL}/api/notify`, {
      method: "POST",
      headers: getHeaders(),
      body: JSON.stringify({ phone, message }),
    });
    return res.json();
  },
};
