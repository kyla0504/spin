import React, { useEffect, useState } from "react";
import { BrowserRouter, Routes, Route, Navigate, Link } from "react-router-dom";
import { motion, AnimatePresence } from "motion/react";
import { CustomerAuth } from "./pages/CustomerAuth";
import { AdminLogin } from "./pages/AdminLogin";
import { CustomerDashboard } from "./pages/CustomerDashboard";
import { BookingPage } from "./pages/BookingPage";
import { AdminDashboard } from "./pages/AdminDashboard";
import { Loader2, LogOut, WashingMachine as Machine } from "lucide-react";

export default function App() {
  const [user, setUser] = useState<any>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const savedUser = localStorage.getItem("user");
    const token = localStorage.getItem("token");
    if (savedUser && token) {
      const parsedUser = JSON.parse(savedUser);
      setUser(parsedUser);
      setIsAdmin(parsedUser.isAdmin || false);
    }
    setLoading(false);
  }, []);

  const handleAuth = (userData: any, token: string) => {
    localStorage.setItem("user", JSON.stringify(userData));
    localStorage.setItem("token", token);
    setUser(userData);
    setIsAdmin(userData.isAdmin || false);
  };

  const handleLogout = () => {
    localStorage.removeItem("user");
    localStorage.removeItem("token");
    setUser(null);
    setIsAdmin(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-brand-light">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
        >
          <Loader2 className="w-12 h-12 text-brand" />
        </motion.div>
      </div>
    );
  }

  return (
    <BrowserRouter>
      <div className="min-h-screen flex flex-col">
        {user && <Header isAdmin={isAdmin} onLogout={handleLogout} />}
        <main className="flex-1">
          <AnimatePresence mode="wait">
            <Routes>
              <Route path="/" element={user ? (isAdmin ? <Navigate to="/admin" /> : <Navigate to="/dashboard" />) : <LandingPage />} />
              <Route path="/login" element={<CustomerAuth type="login" onAuth={handleAuth} />} />
              <Route path="/register" element={<CustomerAuth type="register" onAuth={handleAuth} />} />
              <Route path="/admin/login" element={<AdminLogin onAuth={handleAuth} />} />
              
              <Route path="/dashboard" element={user && !isAdmin ? <CustomerDashboard /> : <Navigate to="/login" />} />
              <Route path="/book" element={user && !isAdmin ? <BookingPage /> : <Navigate to="/login" />} />
              
              <Route path="/admin" element={user && isAdmin ? <AdminDashboard /> : <Navigate to="/admin/login" />} />
            </Routes>
          </AnimatePresence>
        </main>
      </div>
    </BrowserRouter>
  );
}

function Header({ isAdmin, onLogout }: { isAdmin: boolean; onLogout: () => void }) {
  return (
    <header className="bg-white/80 backdrop-blur-md border-b border-blue-50 px-6 py-4 sticky top-0 z-50 shadow-sm">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <Link to="/" className="flex items-center gap-3 group">
          <div className="bg-brand rounded-xl p-2.5 text-white shadow-lg shadow-blue-100 group-hover:scale-110 transition-transform">
            <Machine size={22} />
          </div>
          <span className="font-black text-2xl tracking-tighter text-slate-900">S.P.I.N</span>
        </Link>
        <div className="flex items-center gap-6">
          {isAdmin ? (
            <span className="text-[10px] font-black bg-brand-light text-brand px-3 py-1.5 rounded-full uppercase tracking-widest border border-blue-100">Control Panel</span>
          ) : (
            <Link to="/book" className="text-xs font-black text-brand hover:text-brand-dark transition-colors uppercase tracking-widest bg-brand-light px-4 py-2 rounded-xl border border-blue-100">Quick Book</Link>
          )}
          <button
            onClick={onLogout}
            className="p-2.5 hover:bg-red-50 rounded-xl text-slate-400 hover:text-red-500 transition-all border border-transparent hover:border-red-100 group"
            title="Secure Logout"
          >
            <LogOut size={20} className="group-hover:-translate-x-0.5 transition-transform" />
          </button>
        </div>
      </div>
    </header>
  );
}

function LandingPage() {
  return (
    <div className="min-h-screen flex flex-col bg-[#F0F9FF]">
      <section className="flex-1 flex flex-col items-center justify-center p-6 relative overflow-hidden">
        {/* Decorative background bubbles from theme */}
        <div className="absolute top-20 right-[10%] w-64 h-64 bg-blue-100 rounded-full blur-[100px] opacity-40 animate-pulse" />
        <div className="absolute bottom-20 left-[10%] w-96 h-96 bg-brand-light rounded-full blur-[100px] opacity-30 animate-pulse delay-1000" />
        
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center max-w-3xl relative z-10"
        >
          <div className="inline-block p-5 bg-white rounded-[2.5rem] shadow-2xl mb-10 border border-blue-50">
            <Machine size={80} className="text-brand" />
          </div>
          
          <div className="space-y-4 mb-12">
            <h1 className="text-7xl font-black text-slate-900 tracking-tighter leading-[1.1]">
              Freshness, <span className="text-brand">Simplified.</span>
            </h1>
            <p className="text-xl text-slate-500 font-bold uppercase tracking-[0.2em] max-w-xl mx-auto">
              Service Processing & Instant Notification
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <Link
              to="/register"
              className="bg-brand text-white px-10 py-5 rounded-[2rem] font-black text-lg hover:bg-brand-dark transition-all transform hover:-translate-y-1 shadow-2xl shadow-blue-200 uppercase tracking-widest"
            >
              Start Experience
            </Link>
            <Link
              to="/login"
              className="bg-white text-slate-700 border-2 border-blue-50 px-10 py-5 rounded-[2rem] font-black text-lg hover:bg-slate-50 transition-all shadow-sm uppercase tracking-widest"
            >
              Member Login
            </Link>
          </div>
          
          <div className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-8 text-left">
            <FeatureCard icon="⚡" title="Instant" desc="Real-time SMS updates on your laundry status" />
            <FeatureCard icon="🧼" title="Premium" desc="Eco-friendly detergents and expert care" />
            <FeatureCard icon="🚚" title="Doorstep" desc="Hassle-free pick-up and delivery options" />
          </div>
        </motion.div>
      </section>
      
      <footer className="p-8 flex items-center justify-between max-w-7xl mx-auto w-full border-t border-blue-50 text-[10px] font-black text-slate-400 uppercase tracking-widest">
        <span>© 2024 S.P.I.N SYSTEMS</span>
        <Link to="/admin/login" className="hover:text-brand transition-colors">Operational Terminal</Link>
      </footer>
    </div>
  );
}

function FeatureCard({ icon, title, desc }: { icon: string, title: string, desc: string }) {
  return (
    <div className="bg-white/50 backdrop-blur-sm p-6 rounded-3xl border border-blue-50 shadow-sm group hover:bg-white transition-all">
      <div className="text-3xl mb-3 group-hover:scale-125 transition-transform origin-left">{icon}</div>
      <h3 className="font-black text-slate-900 mb-1">{title}</h3>
      <p className="text-slate-500 text-[11px] font-bold leading-relaxed">{desc}</p>
    </div>
  );
}
